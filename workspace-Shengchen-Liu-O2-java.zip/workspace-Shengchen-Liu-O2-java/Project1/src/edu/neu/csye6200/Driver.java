package edu.neu.csye6200;

public class Driver {

	public static void main(String[] args) {
		Final.demo();

	}

}
