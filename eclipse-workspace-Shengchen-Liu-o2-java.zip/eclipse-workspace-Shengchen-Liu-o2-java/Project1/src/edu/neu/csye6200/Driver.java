package edu.neu.csye6200;
public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		School.demo();
		Company.demo();
	}

}
/**
 * Console output:
 * 
5 students in list.
Student: Andrew Wiggins. Age: 22. GPA: 4.0
Student: Jeremy Lin. Age: 28. GPA: 3.9
Student: Stephen Curry. Age: 28. GPA: 3.7
Student: Tyrus Jones. Age: 26. GPA: 3.7
Student: Jimmy Butler. Age: 29. GPA: 3.5
4 employees in list.
Employee: Rick Adelman. Age: 67. Hourly wage: $20000.0
Employee: Zach Lavine. Age: 21. Hourly wage: $5000.0
Employee: Karl Towns. Age: 45. Hourly wage: $4500.0
Employee: Glen Taylor. Age: 60. Hourly wage: $4000.0
 **/

