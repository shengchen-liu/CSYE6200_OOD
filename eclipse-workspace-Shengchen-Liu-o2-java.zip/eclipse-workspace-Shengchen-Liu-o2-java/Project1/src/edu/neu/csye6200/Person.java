package edu.neu.csye6200;

public class Person{
	private String firstName;
	private String lastName;
	private int age;
		
	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String fName) {
		firstName = fName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lName) {
		lastName = lName;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int AGE) {
		age = AGE;
	}



}
